# NuScale Power — AI Financial Analyzer

> An AI-powered financial analysis dashboard built on SEC 10-K filings for NuScale Power (SMR), leveraging the Claude API for real-time financial insights.

🔗 **[Live Demo](https://YOUR_USERNAME.github.io/nuscale-financial-analyzer/)**

---

## Overview

This project demonstrates the intersection of **financial analysis**, **AI integration**, and **data visualization** — applied to one of the most compelling emerging sectors in clean energy: Small Modular Reactors (SMR).

I built this tool to analyze NuScale Power's financial viability using their publicly available SEC 10-K filings (FY2022–2024). Rather than a static report, the dashboard uses the **Claude API** to generate dynamic, context-aware financial insights on demand.

---

## Features

| Feature | Description |
|---|---|
| **Financial Dashboard** | Key metrics: revenue, net loss, cash runway, burn rate |
| **Interactive Charts** | Revenue vs loss trends, cash position, operating expenses |
| **Peer Comparison** | NuScale vs Oklo Inc. — liquidity, burn rate, regulatory status |
| **AI Analysis Engine** | Ask any question about NuScale's financials → Claude API responds with data-backed insights |
| **Quick Query Templates** | Pre-built prompts for liquidity risk, competitive moat, path to profitability |

---

## Tech Stack

- **Frontend**: Vanilla HTML/CSS/JavaScript
- **Charts**: Chart.js
- **AI Engine**: Anthropic Claude API (`claude-sonnet-4-20250514`)
- **Data Source**: NuScale Power SEC 10-K Filings (FY2022–2024)
- **Deployment**: GitHub Pages

---

## Key Findings (FY2024)

- Revenue grew **+62% YoY** to $37M, though the company remains pre-commercial
- Net loss widened to **−$348M**, driven by R&D and commercialization spend
- Cash burn improved significantly (**−42% YoY**) to $108.7M/year
- Estimated **3.7-year cash runway** (~$447M total liquidity)
- NuScale holds the **only U.S. NRC Standard Design Approval** among SMR developers — a significant regulatory moat vs. peers like Oklo Inc.

---

## Why NuScale?

NuScale is a genuinely differentiated case study:

- **First-mover regulatory advantage** in a capital-intensive, high-barrier industry
- **AI integration** (collaboration with Oak Ridge National Laboratory for fuel management)
- **Pre-revenue stage** with clear path to commercialization — ideal for financial modeling and scenario analysis
- Positioned at the intersection of **nuclear energy**, **AI-driven operations**, and **global decarbonization trends**

---

## Project Structure

```
nuscale-financial-analyzer/
├── index.html        # Main dashboard (single-file app)
└── README.md
```

---

## How to Run Locally

```bash
git clone https://github.com/YOUR_USERNAME/nuscale-financial-analyzer.git
cd nuscale-financial-analyzer
open index.html
```

> Note: The AI Analysis feature requires an active Anthropic API key. The app calls `https://api.anthropic.com/v1/messages` directly from the browser. For production use, route API calls through a backend to protect your API key.

---

## What I Learned

- How to extract and structure financial data from SEC 10-K filings
- Prompt engineering for domain-specific financial analysis using LLMs
- Competitive analysis methodology in an emerging technology sector
- Building AI-augmented tools that turn raw financial data into actionable insights

---

## Background

Built as part of a portfolio project exploring AI applications in financial analysis. Data sourced entirely from publicly available SEC EDGAR filings.

**Areas of interest**: Business Analysis · Financial Modeling · AI Integration · Clean Energy Finance

---

## License

MIT License — feel free to fork and adapt for your own analysis projects.
